package edu.gcu.topic3_3;

public interface WeaponInterface {
    void fireWeapon();
    void fireWeapon(int power);
    void activate(boolean enabled);
}
