package edu.gcu.topic3_2.base;

public interface ShapeInterface {
    int calculateArea();
}
