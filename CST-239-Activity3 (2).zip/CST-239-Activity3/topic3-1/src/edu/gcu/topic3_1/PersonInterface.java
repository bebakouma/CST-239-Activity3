package edu.gcu.topic3_1;

public interface PersonInterface {
    void walk();
    void run();
    boolean isRunning();
}